/*
         Created by Zephyrine 
        Telegram : @rainoneday
   All Right Reversed By Zephyrine
*/

module.exports = {
    TokenS: "TOKEN_BOT_MU",
    admins: ["7308812889"]
};