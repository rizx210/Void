/*
         Created by Zephyrine 
        Telegram : @rainoneday
   All Right Reversed By Zephyrine
*/

module.exports = {
    TokenS: "7654847160:AAGSQIpW3lKYNk3z10vInCne0K0urZRfS1Q",
    admins: ["7308812889"]
};